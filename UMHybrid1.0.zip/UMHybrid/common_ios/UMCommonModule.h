//
//  UMCommonModule.h
//  Hybrid_Component
//
//  Created by wangfei on 2017/10/11.
//  Copyright © 2017年 wangkai. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UMCommon/UMCommon.h>
@interface UMCommonModule : NSObject
+ (void)initWithAppkey:(NSString *)appkey channel:(NSString *)channel;
@end
