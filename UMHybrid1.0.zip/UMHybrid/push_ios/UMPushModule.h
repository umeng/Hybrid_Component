//
//  UMPushModule.h
//  UMComponent
//
//  Created by wyq.Cloudayc on 11/09/2017.
//  Copyright © 2017 Umeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface UMPushModule : NSObject

+ (BOOL)execute:(NSString *)parameters webView:(UIWebView *)webView;

@end
